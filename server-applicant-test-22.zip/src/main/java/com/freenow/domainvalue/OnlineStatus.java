package com.freenow.domainvalue;

public enum OnlineStatus
{
    ONLINE, OFFLINE
}
