package com.freenow.domainvalue;

public enum EngineType {
    ELECTRIC,GAS
}
