package com.freenow.domainvalue;

public enum GearType {
    AUTOMATIC,MANUAL
}
